/**
  ******************************************************************************
  * @file    main.c
  * @author  nnd@isep.ipp.pt
  * @version V2.1
  * @date    28/09/2023
  * @brief   SISTR Example project for STM32F103RBT6
  ******************************************************************************
*/


#include "stm32f10x.h"

/* @PT
 * main.c: configura o GPIOA5 como saída e activa-a (ligando o LED da placa)
 * Abrir o ficheiro RM0008  - Reference Manual do STM32F103xx.
 * A página 170 explica o MODE e CNF de cada GPIO.
 * Validar esta configuraçao usando a perspectiva de Debug do STM32CubeIDE fazendo:
 * Run->Debug; Run-> Resume; Run->Suspend;
 * Duplo click no GPIOA na janela SFR (direita) para obter os valores do microcontrolador.
 *
 * @EN
 * main.c: Configures GPIOA5 as an output and activate it (turns on the LED in the board)
 * Open the file RM0008 - STM32F103xx Reference Manual.
 * The page 170 explains the MODE and CNF for each GPIO.
 * Validate this configuration using the STM32CubeIDE's debug perspective by doing:
 * Run->Debug; Run-> Resume; Run->Suspend;
 * Double-click on GPIOA in the SRF Window (right) to fetch the values from the microcontroller.
 *
 * */










void my_delay(uint32_t delay_value)
{
	while(delay_value > 0)
	{
		delay_value--;
	}
}

#include "stm32f10x.h"






void RCC_Config_HSE_PLL_Max()
{

	RCC_DeInit(); 												// Limpar configs


	RCC_HSEConfig(RCC_HSE_ON);  //HSI Enabled
		while(RCC_GetFlagStatus(RCC_FLAG_HSERDY)== RESET); //verify if the clock has started
		FLASH_SetLatency(FLASH_Latency_2);//Configurar o Flash EXPECIFICARRRRRR
		RCC_HCLKConfig(RCC_SYSCLK_Div1);//Configurar AHB   Divide por 1 pois entra 72 MHz a frequencia máxima
		RCC_PCLK1Config(RCC_HCLK_Div2);//Configurar APB1   Divide por 2 pois 72/2=36 que é a frequência máxima de PCLK1
		RCC_PCLK2Config(RCC_HCLK_Div1);//Configurar APB2   Divide por 1 pois 72/1=72 que é a frequência máxima de PCLK2
		RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_6);
		RCC_PLLCmd(ENABLE);//Ativar PLL
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY)== RESET);//Verificar PLL
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);//Configurar SYSCLK
		while(RCC_GetSYSCLKSource() !=0x08);//Verificar SYSCLK

	rcc_lcd_info();


}



void exercicio1()
{

	//USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

	//Inicialização do TX da USART2 - GPIOA2
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	//Inicialização do RX da USART2 - GPIOA3
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);


	USART_InitTypeDef USART_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;

	USART_Init(USART2, &USART_InitStructure); //Inicialização da USART
	USART_Cmd(USART2, ENABLE); //Ativação da USART



	while(1)
	{
		while(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET);

		uint8_t RxData;
		RxData = USART_ReceiveData(USART2);

		USART_ClearFlag(USART2,USART_FLAG_RXNE);

		while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
		USART_SendData(USART2,RxData);
	}
}


void exercicio2()
{
		/* Configuração NVIC */

		NVIC_InitTypeDef NVIC_InitStructure;
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
		NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStructure);


		USART_InitTypeDef USART_InitStructure;
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
		USART_InitStructure.USART_BaudRate = 115200;
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
		USART_InitStructure.USART_StopBits = USART_StopBits_1;
		USART_InitStructure.USART_Parity = USART_Parity_No;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;

		USART_Init(USART2, &USART_InitStructure); //Inicialização da USART
		USART_Cmd(USART2, ENABLE); //Ativação da USART

		USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);



}




int main(void)
{
	 RCC_DeInit();

    while(1)
    {
    	RCC_Config_HSE_PLL_Max();
    	exercicio1();
    }
}
